import { ISensor } from './../../../../../fccore/sensor';
import { DaoService } from './../../../../../fccore/service/dao.service';

import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NzModalRef } from 'ng-zorro-antd';

declare var angular: any;

@Component({
  selector: 'sys-sensorregistry',
  templateUrl: './sensorregistry.dialog.html',
  styles: [`
  ::ng-deep .registrysensor-dialog-wrap .ant-modal-body{
    padding: 16px 0 0;
  }
  ::ng-deep .registrysensor-dialog .edituser-dialog-footer {
    border-top: 1px solid #e9e9e9;
    padding: 10px 16px 10px 10px;
    text-align: right;
    border-radius: 0 0 4px 4px;
  }
  `]
})
export class FcRegistrySensorComponent implements OnInit {
  //
  validateForm: FormGroup;
  @Input()
  tableName: string;
  @Input()
  codeName: string;
  @Input()
  sensorFunc: string;
  @Input()
  type: string;
  @Input()
  description: string;
  @Input()
  imgFile: string;
  // 用户信息
  userInfo: any;

  imageName = '';

  constructor(private fb: FormBuilder, private subject: NzModalRef, public daoService: DaoService
  ) { }
  ngOnInit(): void {
    // 表单验证
    this.validateForm = this.fb.group({
      tableName :  [null, [Validators.required]],
      codeName:  [null, [Validators.required]],
      sensorFunc:  [null, [Validators.required]],
      type:  [null, [Validators.required]],
      description:  [null, [Validators.required]],
      imgFile:  [null, [Validators.required]],
    });
  }
  getFormControl(name) {
    return this.validateForm.controls[name];
  }
  handleOk() {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
    }
    // this.sensor = {
    //   codeName: 'LSV8',
    //   tableName: '0拉丝机',
    //   sensorFunc: '测长',
    //   type: 'LS',
    //   description: '备注',
    //   imgFile: 'http://localhost:3000/uploads/img/LSV1.jpg'
    //   };
    const test = {
      codeName: 'LSV8',
      tableName: '0拉丝机',
      sensorFunc: '测长',
      type: 'LS',
      description: '备注'
    };

    const fd = new FormData();

    fd.append('data', angular.toJson(test));

    this.daoService.registerSensors(fd);
  }
  handleCancel() {
    this.subject.destroy('onCancel');
  }
  openPath() {
    const docu = document.getElementById('tableName').click();
  }

}
